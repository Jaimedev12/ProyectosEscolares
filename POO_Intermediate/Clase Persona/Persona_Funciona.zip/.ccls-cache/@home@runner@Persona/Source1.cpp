#include <iostream>
#include <string>

using namespace std;


Class Person{

  private:
      string name;
      int age;
      double masa;

  public:
      Person();
      Person(string name, int age, int masa);

      void showData();

};

Person::Person() {
    this->name = "";
    this->age = NULL;
    this->masa = NULL;
}

Person::Person(string name, int age, int masa) {
    this->name = name;
    this->age = age;
    this->masa = masa;
}

Person::showData() {
    cout << "Nombre: " << this->name << endl;
    cout << "Edad: " << this->edad << endl;
    cout << "Masa: " << this->masa << endl;
}

int main() {

    Person person1("Jaime", 18, 10);
    person1.showData();
    return 0;

}